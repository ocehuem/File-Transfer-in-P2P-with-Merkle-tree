import os
import sys
import time
import argparse
import socket
import json
import hashlib
import threading
from datetime import datetime

class Peer:
    def __init__(self, shared_directory='./shared', port=8000):
        self.shared_directory = shared_directory
        self.port = port
        self.id = hashlib.sha256(f"{socket.gethostname()}:{port}:{datetime.now()}".encode()).hexdigest()[:12]
        self.peers = {}  # {peer_id: (ip, port)}
        self.available_files = {}  # {file_hash: filepath}
        self.running = False
        
        # Create shared directory if it doesn't exist
        if not os.path.exists(shared_directory):
            os.makedirs(shared_directory)
            
        # Index local files
        self.index_local_files()
    
    def start(self):
        """Start the peer services"""
        self.running = True
        print(f"Peer {self.id} starting on port {self.port}")
        
        # Start peer discovery in a separate thread
        self.discovery_thread = threading.Thread(target=self._run_discovery)
        self.discovery_thread.daemon = True
        self.discovery_thread.start()
        
        # Start server socket to accept incoming connections
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            self.server_socket.bind(('0.0.0.0', self.port))
            self.server_socket.listen(5)
            self.server_thread = threading.Thread(target=self._server_loop)
            self.server_thread.daemon = True
            self.server_thread.start()
        except Exception as e:
            print(f"Error starting server: {e}")

    def _server_loop(self):
        """Listen for incoming connections"""
        self.server_socket.settimeout(1.0)  # Add timeout to allow clean shutdown
        while self.running:
            try:
                client_sock, client_addr = self.server_socket.accept()
                handler = threading.Thread(target=self._handle_client, args=(client_sock, client_addr))
                handler.daemon = True
                handler.start()
            except socket.timeout:
                continue  # Just retry on timeout
            except Exception as e:
                if self.running:  # Only print if not caused by stopping
                    print(f"Server error: {e}")
    
    def _handle_client(self, client_sock, client_addr):
        """Handle an incoming client connection"""
        try:
            data = client_sock.recv(8192)
            if not data:
                return
                
            request = json.loads(data.decode())
            request_type = request.get("type")
            
            if request_type == "file_list_request":
                # Send local file list
                local_files = []
                for file_hash, filepath in self.available_files.items():
                    filename = os.path.basename(filepath)
                    local_files.append({
                        'filename': filename,
                        'filesize': os.path.getsize(filepath),
                        'file_hash': file_hash
                    })
                
                response = {
                    "status": "ok",
                    "files": local_files
                }
                client_sock.sendall(json.dumps(response).encode())
                
            elif request_type == "file_request":
                # Handle file metadata request
                file_hash = request.get("file_hash")
                if file_hash in self.available_files:
                    filepath = self.available_files[file_hash]
                    filename = os.path.basename(filepath)
                    filesize = os.path.getsize(filepath)
                    merkle_root = self.calculate_merkle_root(filepath)
                    
                    response = {
                        "status": "ok",
                        "filename": filename,
                        "filesize": filesize,
                        "merkle_root": merkle_root
                    }
                else:
                    response = {
                        "status": "error",
                        "message": "File not found"
                    }
                client_sock.sendall(json.dumps(response).encode())
                
            elif request_type == "file_data_request":
                # Handle actual file transfer
                file_hash = request.get("file_hash")
                if file_hash in self.available_files:
                    filepath = self.available_files[file_hash]
                    
                    # First send a simple "ready" response
                    response = {"status": "ready"}
                    client_sock.sendall(json.dumps(response).encode())
                    
                    # Small delay to ensure client is ready
                    time.sleep(0.5)
                    
                    # Send the file in chunks
                    with open(filepath, 'rb') as f:
                        while chunk := f.read(4096):  # Use smaller chunks
                            client_sock.sendall(chunk)
                            time.sleep(0.01)  # Small delay between chunks
                else:
                    response = {
                        "status": "error",
                        "message": "File not found"
                    }
                    client_sock.sendall(json.dumps(response).encode())
                    
        except Exception as e:
            print(f"Error handling client {client_addr}: {e}")
        finally:
            client_sock.close()

    def _run_discovery(self):
        """Periodically discover peers"""
        while self.running:
            self.discover_peers()
            time.sleep(30)  # Discover peers every 30 seconds
    
    def discover_peers(self):
        """Basic peer discovery - simplified for this implementation"""
        # In a real implementation, this would use UDP broadcast or a discovery server
        print("Searching for peers...")
        # Just simulate for now - using the manually added peers
    
    def stop(self):
        """Stop the peer service"""
        self.running = False
        if hasattr(self, 'server_socket'):
            try:
                self.server_socket.close()
            except:
                pass
        print("Peer service stopped.")
    
    def index_local_files(self):
        """Index all files in the shared directory"""
        if not os.path.exists(self.shared_directory):
            return
            
        for root, _, files in os.walk(self.shared_directory):
            for filename in files:
                filepath = os.path.join(root, filename)
                file_hash = self.calculate_file_hash(filepath)
                self.available_files[file_hash] = filepath
    
    def calculate_file_hash(self, filepath):
        """Calculate SHA-256 hash of a file"""
        hasher = hashlib.sha256()
        with open(filepath, 'rb') as f:
            while chunk := f.read(8192):
                hasher.update(chunk)
        return hasher.hexdigest()
    
    def search_files(self, query):
        """Search for files matching the query"""
        results = []
        
        # Search local files
        for file_hash, filepath in self.available_files.items():
            filename = os.path.basename(filepath)
            if query.lower() in filename.lower():
                results.append({
                    'filename': filename,
                    'filesize': os.path.getsize(filepath),
                    'file_hash': file_hash,
                    'location': 'local',
                    'peer_id': self.id
                })
        
        # Search remote files
        for peer_id, (ip, port) in self.peers.items():
            if peer_id != self.id:  # Skip self
                remote_files = self.get_peer_files(peer_id)
                for file_info in remote_files:
                    if query.lower() in file_info['filename'].lower():
                        results.append({
                            'filename': file_info['filename'],
                            'filesize': file_info['filesize'],
                            'file_hash': file_info['file_hash'],
                            'location': 'remote',
                            'peer_id': peer_id
                        })
                    
        return results
    
    def get_peer_files(self, peer_id):
        """Get files from a specific peer"""
        # If it's the local peer, return local files
        if peer_id == self.id:
            local_files = []
            for file_hash, filepath in self.available_files.items():
                filename = os.path.basename(filepath)
                local_files.append({
                    'filename': filename,
                    'filesize': os.path.getsize(filepath),
                    'file_hash': file_hash
                })
            return local_files
        
        # For remote peers
        try:
            # Check if we know this peer
            if peer_id not in self.peers:
                print(f"Unknown peer: {peer_id}")
                return []
            
            peer_ip, peer_port = self.peers[peer_id]
            
            # Create a socket connection to the peer
            client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            client_socket.settimeout(5)  # 5 second timeout
            
            try:
                # Try to connect to the peer
                client_socket.connect((peer_ip, peer_port))
                
                # Send file list request
                request = {
                    "type": "file_list_request"
                }
                client_socket.sendall(json.dumps(request).encode())
                
                # Receive response
                response = json.loads(client_socket.recv(8192).decode())
                
                if response.get("status") == "ok":
                    return response.get("files", [])
                else:
                    print(f"Error getting files from peer {peer_id}: {response.get('message', 'Unknown error')}")
                    return []
                    
            except socket.timeout:
                print(f"Connection to peer {peer_id} timed out")
                return []
            except ConnectionRefusedError:
                print(f"Connection to peer {peer_id} refused")
                return []
            except Exception as e:
                print(f"Error communicating with peer {peer_id}: {str(e)}")
                return []
            finally:
                client_socket.close()
                
        except Exception as e:
            print(f"Error getting files from peer {peer_id}: {str(e)}")
            return []
    
    def get_all_peer_files(self):
        """Get files from all known peers"""
        all_files = {
            'local': [],  # Local files
            'peers': {}   # Remote peers' files
        }
        
        # Add local files
        for file_hash, filepath in self.available_files.items():
            filename = os.path.basename(filepath)
            all_files['local'].append({
                'filename': filename,
                'filesize': os.path.getsize(filepath),
                'file_hash': file_hash
            })
        
        # Add remote peers' files
        for peer_id, (ip, port) in self.peers.items():
            if peer_id != self.id:  # Skip self
                peer_files = self.get_peer_files(peer_id)
                if peer_files:
                    all_files['peers'][peer_id] = peer_files
                    
        return all_files
    
    # Merkle tree implementation
    def chunk_file(self, file_path, chunk_size=1024):
        """Break a file into chunks for building the merkle tree"""
        chunks = []
        with open(file_path, 'rb') as f:
            while chunk := f.read(chunk_size):
                # Convert binary data to string for hashing
                chunks.append(chunk.decode('utf-8', errors='ignore'))
        return chunks if chunks else [""]  # Return at least one chunk even for empty files
    
    def merkle_tree(self, chunks):
        """Create a Merkle tree from file chunks and return the root hash"""
        if len(chunks) == 1:
            return hashlib.sha256(chunks[0].encode()).hexdigest()

        mid = len(chunks) // 2
        left_hash = self.merkle_tree(chunks[:mid])
        right_hash = self.merkle_tree(chunks[mid:])

        return hashlib.sha256((left_hash + right_hash).encode()).hexdigest()
    
    def calculate_merkle_root(self, filepath, chunk_size=1024):
        """Calculate the Merkle tree root hash for a file"""
        chunks = self.chunk_file(filepath, chunk_size)
        return self.merkle_tree(chunks)
    
    def download_file(self, file_hash, peer_id, destination):
        """Download a file from a peer with Merkle tree verification"""
        if peer_id == self.id:
            print("File is already available locally.")
            return True
        
        if peer_id not in self.peers:
            print(f"Unknown peer: {peer_id}")
            return False
            
        peer_ip, peer_port = self.peers[peer_id]
        print(f"Connecting to peer {peer_id} at {peer_ip}:{peer_port}...")
        
        try:
            # Connect to the peer
            client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            client_socket.settimeout(30)  # Longer timeout for file transfers
            client_socket.connect((peer_ip, peer_port))
            
            # Send file request
            request = {
                "type": "file_request",
                "file_hash": file_hash
            }
            client_socket.sendall(json.dumps(request).encode())
            
            # Receive response with file metadata
            response_data = client_socket.recv(8192)
            response = json.loads(response_data.decode())
            
            if response.get("status") != "ok":
                print(f"Peer reported error: {response.get('message', 'Unknown error')}")
                return False
                
            filename = response.get("filename")
            filesize = response.get("filesize")
            merkle_root = response.get("merkle_root")
            
            print(f"Downloading {filename} ({filesize} bytes)...")
            
            # Create a new socket for the file data transfer
            data_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            data_socket.settimeout(60)  # Longer timeout for file transfers
            data_socket.connect((peer_ip, peer_port))
            
            # Request the file data
            data_request = {
                "type": "file_data_request",
                "file_hash": file_hash
            }
            data_socket.sendall(json.dumps(data_request).encode())
            
            # Get the "ready" response
            ready_response = data_socket.recv(8192)
            ready_data = json.loads(ready_response.decode())
            
            if ready_data.get("status") != "ready":
                print(f"Peer not ready to send file: {ready_data.get('message', 'Unknown error')}")
                return False
            
            # Receive file data
            destination_path = os.path.join(destination, filename)
            with open(destination_path, 'wb') as f:
                bytes_received = 0
                while bytes_received < filesize:
                    try:
                        chunk = data_socket.recv(4096)  # Use smaller chunks
                        if not chunk:
                            break
                        f.write(chunk)
                        bytes_received += len(chunk)
                        print(f"Progress: {bytes_received}/{filesize} bytes ({bytes_received/filesize*100:.1f}%)", end="\r")
                    except socket.timeout:
                        break
                print()  # New line after progress
            
            # Close data socket
            data_socket.close()
            
            if bytes_received < filesize:
                print(f"Incomplete download: {bytes_received}/{filesize} bytes received")
                return False
                
            # Calculate the merkle root of the downloaded file
            calculated_merkle_root = self.calculate_merkle_root(destination_path)
            
            # Verify the merkle root
            if calculated_merkle_root == merkle_root:
                print("File integrity verified using Merkle tree!")
                return True
            else:
                print("File integrity check failed. The file may be corrupted.")
                return False
                
        except Exception as e:
            print(f"Error downloading file: {e}")
            return False
        finally:
            client_socket.close()

def main():
    parser = argparse.ArgumentParser(description='Simple P2P File Sharing with Merkle Tree Verification')
    parser.add_argument('--port', type=int, default=8000, help='Port to listen on')
    parser.add_argument('--directory', type=str, default='./shared', help='Directory to share files from')
    args = parser.parse_args()
    
    # Create and start the peer
    peer = Peer(shared_directory=args.directory, port=args.port)
    peer.start()
    
    # For testing - manually add another peer
    test_peer_ip = input("Enter another peer's IP (leave empty for solo mode): ")
    if test_peer_ip:
        test_peer_port = int(input("Enter peer's port (default 8000): ") or "8000")
        test_peer_id = "test_peer_123"  # In real implementation, this would come from discovery
        peer.peers[test_peer_id] = (test_peer_ip, test_peer_port)
        print(f"Added test peer: {test_peer_id} at {test_peer_ip}:{test_peer_port}")

    # Add self to peers list
    peer.peers[peer.id] = ('127.0.0.1', peer.port)
    
    print("\nSimple P2P File Sharing with Merkle Tree Verification")
    print("===================================================")
    print(f"Your peer ID: {peer.id}")
    print(f"Listening on port: {peer.port}")
    print(f"Sharing files from: {peer.shared_directory}")
    
    try:
        while True:
            print("\nOptions:")
            print("1. Search for files")
            print("2. List local files")
            print("3. List known peers")
            print("4. Download a file")
            print("5. View all peer files")
            print("6. Verify file integrity")
            print("7. Quit")
            
            choice = input("\nEnter your choice: ")
            
            if choice == '1':
                query = input("Enter search query: ")
                results = peer.search_files(query)
                
                if not results:
                    print("No files found matching your query.")
                else:
                    print("\nSearch Results:")
                    for i, result in enumerate(results):
                        location = "Local" if result['location'] == 'local' else f"Remote ({result['peer_id']})"
                        print(f"{i+1}. {result['filename']} - {result['filesize']} bytes - {location}")
                
            elif choice == '2':
                print("\nLocal Files:")
                for file_hash, filepath in peer.available_files.items():
                    filename = os.path.basename(filepath)
                    filesize = os.path.getsize(filepath)
                    print(f"{filename} - {filesize} bytes - {file_hash[:8]}...")
                
            elif choice == '3':
                print("\nKnown Peers:")
                if not peer.peers:
                    print("No peers discovered yet. Waiting for peer discovery...")
                else:
                    for peer_id, (ip, port) in peer.peers.items():
                        print(f"{peer_id} - {ip}:{port}")
                
            elif choice == '4':
                query = input("Enter search query: ")
                results = peer.search_files(query)
                
                if not results:
                    print("No files found matching your query.")
                else:
                    print("\nSearch Results:")
                    for i, result in enumerate(results):
                        location = "Local" if result['location'] == 'local' else f"Remote ({result['peer_id']})"
                        print(f"{i+1}. {result['filename']} - {result['filesize']} bytes - {location}")
                    
                    try:
                        selection = int(input("\nEnter number to download (0 to cancel): "))
                        if selection > 0 and selection <= len(results):
                            selected_file = results[selection-1]
                            
                            if selected_file['location'] == 'local':
                                print("File is already available locally.")
                            else:
                                destination = input(f"Enter download destination (default: {peer.shared_directory}): ")
                                if not destination:
                                    destination = peer.shared_directory
                                
                                if not os.path.exists(destination):
                                    os.makedirs(destination)
                                
                                # Download the file with Merkle tree verification
                                success = peer.download_file(
                                    selected_file['file_hash'],
                                    selected_file['peer_id'],
                                    destination
                                )
                                
                                if success:
                                    print("Download complete and verified with Merkle tree!")
                                else:
                                    print("Download failed or integrity check failed.")
                    except ValueError:
                        print("Invalid selection.")
                
            elif choice == '5':
                print("\nFetching files from all peers...")
                all_files = peer.get_all_peer_files()
                
                # Display local files
                print("\nLOCAL FILES:")
                print("-" * 50)
                if not all_files['local']:
                    print("No local files shared.")
                else:
                    for file in all_files['local']:
                        print(f"{file['filename']} - {file['filesize']} bytes - {file['file_hash'][:8]}...")
                
                # Display remote peers' files
                print("\nREMOTE PEERS FILES:")
                if not all_files['peers']:
                    print("No peers discovered yet. Waiting for peer discovery...")
                else:
                    for peer_id, files in all_files['peers'].items():
                        print(f"\nPEER: {peer_id}")
                        print("-" * 50)
                        for file in files:
                            print(f"{file['filename']} - {file['filesize']} bytes - {file['file_hash'][:8]}...")
            elif choice == '6':
                print("\nVerify file integrity using Merkle tree")
                filepath = input("Enter the path to the file to verify: ")
                
                if not os.path.exists(filepath):
                    print("File does not exist.")
                else:
                    merkle_root = peer.calculate_merkle_root(filepath)
                    print(f"Merkle root hash: {merkle_root}")
                    print("File integrity can be verified by comparing this Merkle root hash with the original.")
                
            elif choice == '7':
                break
                
            else:
                print("Invalid choice. Please try again.")
                
    except KeyboardInterrupt:
        print("\nShutting down...")
    finally:
        peer.stop()
        print("Goodbye!")

if __name__ == "__main__":
    main()